import math
import sys
def main():
    class Water_bill:
        def __init__(self, BKH_app, ratio, guests):
            self.BKH_app = BKH_app
            self.ratio = ratio
            self.guests=guests
        def TOTAL_WATER_CONSUMED_IN_LITERS(self):
            liters=0
            if BKH_app=="2":
                liters+=900
                liters+=guests*300
            else:
                liters+=1500
                liters+=guests*300
            return liters
        def TOTAL_COST(self):
            x=0
            if BKH_app=="2":
                x+=(900/(int(ratio[0])+int(ratio[2])))
            else:
                x+=(1500/(int(ratio[0])+int(ratio[2])))
            corporation_water=x*1*int(ratio[0])
            Borewell_water=(x*1.5*int(ratio[2]))
            app_cost=math.ceil(corporation_water+Borewell_water)
            guests_liters=guests*300
            guests_costs=0
            for i in range(4):
                if i==0:
                    if guests_liters<500:
                        guests_costs+=guests_liters*2
                        break
                    else:
                        guests_costs+=500*2
                        guests_liters-=500
                elif i==1:
                    if guests_liters<1500:
                        guests_costs+=guests_liters*3
                        break
                    else:
                        guests_costs+=1000*3
                        guests_liters-=1000
                elif i==2:
                    if guests_liters<3000:
                        guests_costs+=guests_liters*5
                        break
                    else:
                        guests_costs+=1500*5
                        guests_liters-=1500
                elif i==3:
                    if guests_liters<3000:
                        guests_costs+=guests_liters*8
                        break
            cost=app_cost+guests_costs
            return cost
    ALLOT_WATER=input().split()
    BKH_app=ALLOT_WATER[1]
    ratio=ALLOT_WATER[2]
    guests=0
    for i in range(10):
        ADD_GUESTS=input().split()
        if ADD_GUESTS[0]!="BILL":
            guests+=int(ADD_GUESTS[1])
        else:
            break
    obj=Water_bill(BKH_app,ratio,guests)
    print(obj.TOTAL_WATER_CONSUMED_IN_LITERS(),obj.TOTAL_COST())

if __name__ == "__main__":
    main()